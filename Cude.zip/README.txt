If you want a source code of this plugin, contact me in discord Cude#3358!
Main Source: https://www.roblox.com/games/300883396/Arcane-Adventures-BROKEN

This game has broken and not work anymore, i remake it in minecraft xD!

REmember, install the plugin in softpend folder